let digital = ["Graduaat Programmeren", "Graduaat Digitale Vormgeving", "Graduaat Systeem- en netwerkbeheer", "Graduaat Internet Of Things", "Bachelor Elektronica-ICT", "Bachelor Toegepaste Informatica"];
digital[6] = "Bachelor Multimedia- en Communicatietechnologie";
// niet de meest ideale manier om de lengte toegevoegd worden ge zet er best [digital.length] ipv 6 das altijd beter cuz lange array gaat ge nie tellen
console.log(digital.length);