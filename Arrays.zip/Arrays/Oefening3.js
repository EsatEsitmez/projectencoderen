let digital = ["Graduaat Programmeren", "Graduaat Digitale Vormgeving", "Graduaat Systeem- en netwerkbeheer", "Graduaat Internet Of Things", "Bachelor Elektronica-ICT", "Bachelor Toegepaste Informatica", "Bachelor Multimedia- en Communicatietechnologie"];

document.getElementById("uitkomst").innerHTML = digital.join("<br>");