let hondenrassen = ["Labrador", "Golden Retriever", "Samojeed", "Dashond", "Shih-Tzu", "Franse Bulldog", "Duitse Herder", "Mopshond", "Pitbull", "Siberische Husky"];

let getal = parseInt(prompt("Kies een getal tussen 1 en 10."));

if (getal >= 0 && getal <= 10) {
    document.getElementById("uitkomst").innerHTML = hondenrassen[getal - 1];
} else {
    document.getElementById("uitkomst").innerHTML = "Sorry, katten niet toegelaten.";
}

