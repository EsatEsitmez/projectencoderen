let hondenrassen = ["Labrador", "Golden Retriever", "Samojeed", "Dashond", "Shih-Tzu", "Franse Bulldog", "Duitse Herder", "Mopshond", "Pitbull", "Siberische Husky"];

hondenrassen.unshift("Chow Chow", "Engelse Bulldog", "Rottweiler", "Maltezer", "Vlinderhondje");

console.log(hondenrassen);