let hondenrassen = ["Chow Chow", "Engelse Bulldog", "Rottweiler", "Maltezer", "Vlinderhondje", "Labrador", "Golden Retriever", "Samojeed", "Dashond", "Shih-Tzu", "Franse Bulldog", "Duitse Herder", "Mopshond", "Pitbull", "Siberische Husky"];

hondenrassen.pop();
hondenrassen.shift();

console.log(hondenrassen);
document.getElementById("uitkomst").innerHTML = hondenrassen.join(", ");
