let vandaag = new Date();
let vandaagMaand = vandaag.getMonth() + 1;
let vandaagJaar = vandaag.getFullYear();
let uitkomst = "";

let DagenPerMaand = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

for (let dagen = 1; dagen <= DagenPerMaand[vandaagMaand - 1]; dagen++){
    uitkomst += dagen + "/" + vandaagMaand + "/" + vandaagJaar + "<br>";
}

document.getElementById("uitkomst").innerHTML = uitkomst;