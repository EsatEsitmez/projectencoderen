let vandaag = new Date();
let vandaagMaand = vandaag.getMonth() + 1;
let vandaagJaar = vandaag.getFullYear();
let uitkomst = "";

let DagenPerMaand = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
let Weekdagen = ["zondag", "maandag", "dinsdag", "woensdag", "donderdag", "vrijdag", "zaterdag"];

for (let dagen = 1; dagen <= DagenPerMaand[vandaagMaand - 1]; dagen++){
    let datumDagInLoop = new Date(vandaagJaar, (vandaagMaand - 1), dagen);
    let weekdag = datumDagInLoop.getDay();

    uitkomst += Weekdagen[weekdag] + ", " + dagen + "/" + vandaagMaand + "/" + vandaagJaar + "<br>";
}

document.getElementById("uitkomst").innerHTML = uitkomst;